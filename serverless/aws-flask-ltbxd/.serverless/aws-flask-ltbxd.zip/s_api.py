import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='mitchel',
    application_name='aws-flask-ltbxd',
    app_uid='lXYVF8cBCbCj9wFvT5',
    org_uid='7f555f83-5c90-487b-8895-557eb47f4b52',
    deployment_uid='6b6f75fd-a041-42c5-9f7c-2fe317b4dc79',
    service_name='aws-flask-ltbxd',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.0.4',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-flask-ltbxd-dev-api', 'timeout': 30}
try:
    user_handler = serverless_sdk.get_user_handler('app.ScrapeLetterboxdFavourites')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
